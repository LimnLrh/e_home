<template>
    <div class="summary">
        <div class="btn">
            <mt-button type="danger" size="large">提交审核</mt-button>
        </div>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped lang="scss">
.summary{
    margin-top: 50px;
}
.btn{
    width: 100%;
    height: 50px;
    position: fixed;
    bottom: 50px;
}
</style>